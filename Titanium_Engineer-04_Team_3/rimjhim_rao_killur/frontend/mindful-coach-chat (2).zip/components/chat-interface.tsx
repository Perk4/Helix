"use client"

import { useEffect, useRef, useState } from "react"
import { Sparkles } from "lucide-react"
import { ChatMessage, TypingIndicator, type ChatMessageData } from "@/components/chat-message"
import { ChatInput } from "@/components/chat-input"

const SUGGESTIONS = [
  "I'm feeling overwhelmed today",
  "Help me set an intention for the week",
  "I need to calm my racing thoughts",
  "How can I build a better morning routine?",
]

export function ChatInterface() {
  const [messages, setMessages] = useState<ChatMessageData[]>([])
  const [input, setInput] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
  }, [messages, isLoading])

  async function sendMessage(text: string) {
    const trimmed = text.trim()
    if (!trimmed || isLoading) return

    const userMessage: ChatMessageData = {
      id: crypto.randomUUID(),
      role: "user",
      content: trimmed,
    }
    setMessages((prev) => [...prev, userMessage])
    setInput("")
    setIsLoading(true)

    try {
      const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: trimmed }),
      })

      if (!res.ok) throw new Error(`Request failed with status ${res.status}`)

      const data = await res.json()
      const reply =
        typeof data === "string"
          ? data
          : (data.response ?? data.reply ?? data.message ?? data.answer ?? JSON.stringify(data))

      setMessages((prev) => [
        ...prev,
        { id: crypto.randomUUID(), role: "assistant", content: String(reply) },
      ])
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content:
            "I couldn't reach the coaching service just now. Please check your connection and try again.",
          error: true,
        },
      ])
    } finally {
      setIsLoading(false)
    }
  }

  const isEmpty = messages.length === 0

  return (
    <div className="flex h-dvh flex-col bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur">
        <div className="mx-auto flex w-full max-w-3xl items-center gap-3 px-4 py-4">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground shadow-[0_0_20px_-2px_var(--color-primary)]">
            <Sparkles className="size-5" />
          </div>
          <div>
            <h1 className="text-base font-semibold leading-tight text-foreground">Mindful Coach</h1>
            <p className="text-xs text-muted-foreground">Your AI companion for clarity and calm</p>
          </div>
        </div>
      </header>

      <div ref={scrollRef} className="flex-1 overflow-y-auto">
        <div className="mx-auto w-full max-w-3xl px-4 py-6">
          {isEmpty ? (
            <div className="flex flex-col items-center justify-center gap-6 py-16 text-center">
              <div className="flex size-16 items-center justify-center rounded-2xl bg-primary/15 text-primary ring-1 ring-primary/30">
                <Sparkles className="size-8" />
              </div>
              <div className="space-y-1.5">
                <h2 className="text-xl font-semibold text-foreground text-balance">
                  How are you feeling today?
                </h2>
                <p className="mx-auto max-w-md text-sm text-muted-foreground text-pretty">
                  I'm here to listen and help you reflect. Share whatever is on your mind, or start
                  with one of these.
                </p>
              </div>
              <div className="grid w-full max-w-lg gap-2 sm:grid-cols-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => sendMessage(s)}
                    className="rounded-xl border border-border bg-card px-4 py-3 text-left text-sm text-card-foreground transition-colors hover:border-primary/50 hover:bg-primary/5"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="flex flex-col gap-5">
              {messages.map((m) => (
                <ChatMessage key={m.id} message={m} />
              ))}
              {isLoading && <TypingIndicator />}
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-border bg-background">
        <div className="mx-auto w-full max-w-3xl px-4 py-4">
          <ChatInput value={input} onChange={setInput} onSubmit={() => sendMessage(input)} disabled={isLoading} />
          <p className="mt-2 text-center text-xs text-muted-foreground">
            Mindful Coach offers supportive reflection, not professional medical advice.
          </p>
        </div>
      </div>
    </div>
  )
}
